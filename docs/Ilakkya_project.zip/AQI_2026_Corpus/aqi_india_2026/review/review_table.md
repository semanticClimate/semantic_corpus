# Corpus review table

| review_status | score | title | pmcid | has_xml | has_pdf |
| --- | ---: | --- | --- | --- | --- |
| review | 9 | Sustainable modular biofiltration system with rainshower technology for AQI refo | PMC12086192 | True | False |
| review | 9 | Explainable forecasting of air quality index using a hybrid random forest and AR | PMC12329590 | True | False |
| review | 9 | A hybrid physics-informed neural and explainable AI approach for scalable and in | PMC12448019 | True | False |
| review | 8 | Assessment and forecasting of particulate matter emissions and structural health | PMC12098713 | True | False |
| review | 8 | Impact of Housing Conditions and Air Quality Awareness with Indoor PM2.5 Levels  | PMC12815361 | True | False |
| review | 8 | Real-time impacts of air pollution on the health, well-being, and daily life of  | PMC13289869 | True | False |
| review | 8 | Identifying AQI Drivers Through Ensemble Learning and LULC-Based Analysis Across |  | False | False |
| review | 8 | Impact of meteorological drivers on air quality index: A case study from Delhi. |  | False | False |
| review | 8 | Evaluating machine learning models and imputation strategies for Air Quality Ind |  | False | False |
| review | 8 | Regression based hybrid machine learning model performance evaluation on air qua |  | False | False |
| review | 7 | Occupational exposure to air pollution and respiratory health among urban street |  | False | False |
| review | 7 | Association between ambient air pollution and increased risk of respiratory dise |  | False | False |
| review | 7 | Assessing Nexus between Human Health and Air Pollutants through Spatiotemporal A |  | False | False |
| review | 7 | Firecracker-induced air pollution and health burden during Diwali: ground and sa |  | False | False |
| review | 7 | Occupational exposure to air pollution and respiratory health among urban street |  | False | False |
| review | 6 | Ensemble stacking of machine learning models for air quality prediction for Hyde | PMC11883379 | True | False |
| review | 6 | Efficient multi-station air quality prediction in Delhi with wavelet and optimiz | PMC12364328 | True | False |
| review | 6 | Effect of Ambient Air Pollutants on Acute changes in Pulmonary Variables and Inf | PMC12572900 | True | False |
| review | 6 | Assessment of Ambient Multipollutant Exposure and Health Impacts Over India Usin | PMC12710085 | True | False |
| review | 6 | A cross-sectional study on the respiratory health status and its determinants am | PMC12995173 | True | False |
| review | 6 | Systematic exposure bias in city-level air quality reporting revealed by 38 year | PMC13199542 | True | False |
| review | 6 | Cost-effective and scalable urban air quality monitoring using image-based deep  | PMC13219415 | True | False |
| review | 6 | Characterizing the Compound Extreme Temperature and PM&lt;sub&gt;2.5&lt;/sub&gt; | PMC13282691 | True | False |
| review | 5 | Real time public display dashboards: Reframing road traffic accidents in India. | PMC13104748 | True | False |
| review | 5 | Deciphering seasonal dynamics and time series forecasting of urban air quality:  |  | False | False |
| review | 4 | Exploring temperature and humidity environment combined with air quality index,  | PMC12007920 | True | False |
| review | 4 | Machine learning-based forecasting of air quality index under long-term environm | PMC12507303 | True | False |
| review | 4 | Ensemble learning for air quality index prediction: integrating gradient boostin | PMC12976265 | True | False |
| review | 4 | Nonlinear meteorological controls on coastal air quality along the Indian East C |  | False | False |
| review | 3 | Exploring regional air pollution transition dynamics: A multi-state markov model | PMC12503330 | True | False |
| review | 3 | A Comprehensive Review of Data-Driven Techniques for Air Pollution Concentration | PMC12526560 | True | False |
| review | 3 | Accurate AQI forecasting in a high-altitude city using a simulated CVOCA-BiLSTM  | PMC12586577 | True | False |
| review | 3 | Impact of Air Pollution on Health: A Rising Concern in Kathmandu, Nepal. | PMC12860666 | True | False |
| review | 3 | Climate Cognition Crisis: Urgent Call to Address Air Pollution and Extreme Heat  | PMC13132106 | True | False |
| review | 3 | The association between physical activity and cardiovascular disease under indoo | PMC13159321 | True | False |
| review | 3 | A hybrid bio-inspired model for predicting urban air pollution using deep learni | PMC13187486 | True | False |
| review | 3 | Enhanced forecasting of air quality index through an integrated deep learning fr |  | False | False |
| review | 3 | A cluster-aware synthetic resampling and machine learning framework for multi-cl |  | False | False |
| review | 1 | Air quality historical correlation model based on time series. | PMC11445545 | True | False |
| review | 1 | Enhancing urban air quality prediction using time-based-spatial forecasting fram | PMC11791089 | True | False |
| review | 1 | Air quality prediction-based big data analytics using hebbian concordance and at | PMC12328754 | True | False |
| review | 1 | Source dynamics and environmental risk of street dust as a vector of human expos | PMC12368213 | True | False |
| review | 1 | Hybrid deep learning model for air quality prediction and its impact on healthca | PMC12901979 | True | False |
| review | 1 | A global score for skin environmental exposure: integrating UV radiation, heat,  | PMC13076557 | True | False |
| review | 0 | Study on the evolution patterns and predictive modeling of ambient air quality i | PMC12355607 | True | False |
| review | -1 | An empirical investigation of environmental impacts of agglomeration economies i | PMC12141506 | True | False |
| review | -1 | IoT-Driven classroom air quality management with deep hierarchical cluster analy | PMC12518576 | True | False |
| review | -1 | Burning issues: trends in newspaper coverage of wildfire events and health. | PMC13223581 | True | False |
| review | -2 | Our children deserve cleaner air. | PMC12675021 | True | False |
| review | -2 | Mapping the Distribution of Tobacco Litter During the Haridwar Kumbh Mela 2021:  | PMC13245708 | True | False |
