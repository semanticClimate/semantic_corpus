# AQI Literature Review Summary

| Metric                        | Value          |
|:------------------------------|:---------------|
| Query Name                    | aqi_india_2026 |
| Repository                    | Europe PMC     |
| Total Papers Retrieved        | 50             |
| Publications with XML         | 37             |
| Publications with PDF         | 0              |
| Papers with Score ≥ 5         | 25             |
| Papers with Score ≥ 5 and XML | 15             |
| Included Papers               | 47             |
| Excluded Papers               | 3              |
| Pending Review                | 0              |