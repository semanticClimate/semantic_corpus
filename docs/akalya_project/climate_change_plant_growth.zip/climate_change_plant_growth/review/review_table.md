# Corpus review table

| review_status | score | title | pmcid | has_xml |
| --- | ---: | --- | --- | --- |
| review | -2 | Loss of vegetation functions during the Paleocene-Eocene Thermal Maximum. | PMC12728184 | True |
| review | -2 | Engineering plant stress responses to combat climate change. | PMC12780301 | True |
| review | -2 | Harnessing endophytic fungi for sustainable agriculture: ecological roles, mecha | PMC13010128 | True |
| review | -2 | Modeling of fractional order DPG model insight global warming and pollution effe | PMC13061935 | True |
| review | -2 | The Arctic vegetation is more sensitive to heatwave-induced photosynthetic decli | PMC13076769 | True |
| review | -2 | Climate Change Impacts on Plant-Parasitic Nematodes in Agroecosystems. | PMC13118505 | True |
| review | -2 | Editorial: Integrative biophysical models to uncover fundamental processes in pl | PMC13121153 | True |
| review | -2 | Editorial: Fungal-plant interactions in a changing environment: from mutualism t | PMC13161122 | True |
| review | -2 | A systematic review on soil microbial shifts under drought stress: a climate-sma | PMC13170800 | True |
| review | -2 | Broccoli plants exposed to the combined threat of climate change and bacterial i | PMC13173881 | True |
| review | -2 | Application of crop growth models in crop yield assessment. | PMC13199339 | True |
| review | -2 | Editorial Closing: Plant Biotic and Abiotic Stresses Special Issue. | PMC13208227 | True |
| review | -2 | Global Warming and Dispersal Limitations Drive the Suitable Habitat Distribution | PMC13210694 | True |
| review | -2 | Climate-Driven Redistribution of Early-Spring Ephemeral Plant Communities in Col | PMC13211235 | True |
| review | -2 | Applications of Gene-Editing Technologies in Enhancing Crop Stress Resistance wi | PMC13211264 | True |
| review | -2 | Fresh aboveground net primary productivity of Tibetan grasslands: Responses of d | PMC13252736 | True |
| review | -2 | Research progress on the interaction between forest carbon sequestration and cli | PMC13255328 | True |
| review | -2 | Physiological Responses, Molecular Basis, and Integrated Regulation of Heat Tole | PMC13258885 | True |
| review | -2 | Predict Suitable Restoration Areas for Typical Vegetation Restoration Species on | PMC13282462 | True |
| review | -2 | Diurnal asymmetric warming promotes the growth of the perennial species Sophora  | PMC13290584 | True |
| review | -2 | Chapter Eight - Advances on responses and mechanisms of lily to heat stress |  | False |
| review | -3 | Warming, stress and survival: terrestrial vegetation dynamics during the Toarcia |  | False |
| review | -3 | Plant response to and recovery from drought. |  | False |
| review | -3 | Response of two mangrove species to elevated temperatures: a comparative study o |  | False |
| review | -3 | Hysteresis response of photosynthetic parameters in different plants to external |  | False |
