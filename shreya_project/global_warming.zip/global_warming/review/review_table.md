# Corpus review table

| review_status | score | title | pmcid | has_xml |
| --- | ---: | --- | --- | --- |
| review | 2 | The boiling frog effect: Global warming delays emotional impacts of air pollutio |  | False |
| review | 2 | Benchmarking Regional Climate Variability in CMIP6 over India in the Recent Acce |  | False |
| review | -1 | A rapidly closing window for coral persistence under global warming. | PMC12589577 | True |
| review | -1 | Neotropical ants are at greater risk from global warming in savanna than in adja | PMC13172437 | True |
| review | -1 | The relationship between environmental literacy and global warming knowledge lev | PMC13285055 | True |
| review | -2 | Global warming impacts on lactating mammalian milk: A systematic review. |  | False |
| review | -2 | Global Warming and the Elderly: A Socio-Ecological Framework. |  | False |
| review | -2 | mGem: A perfect storm in the era of global warming-the convergence between therm |  | False |
| review | -2 | Predicting biomass global warming potential with FT-NIR spectroscopy. | PMC12484551 | True |
| review | -2 | Who's Interested in Global Warming? | PMC12610921 | True |
| review | -2 | Dousing the burning inequity of global warming for people experiencing homelessn | PMC12620599 | True |
| review | -2 | German Anglers' Views on Global Warming - Implications for Climate Change Monito | PMC12669331 | True |
| review | -2 | Global Warming Drives Phenological Shifts and Hinders Reproductive Success in a  | PMC12802391 | True |
| review | -2 | Variation in Tree Growth Increases With Global Warming. | PMC12843879 | True |
| review | -2 | Emergence of the enhanced equatorial Atlantic warming as a fingerprint of global | PMC12865183 | True |
| review | -2 | Author Correction: Malaria trends in Ethiopian highlands track the 2000 'slowdow | PMC12905355 | True |
| review | -2 | Rising Air-Conditioning Use Intensifies Global Warming. | PMC12936058 | True |
| review | -2 | Global Warming and the Elderly: A Socio-Ecological Framework | PMC12941366 | True |
| review | -2 | Environmental Impact of Pentaspline Pulsed Field Ablation-Global Warming or Arct | PMC12944332 | True |
| review | -2 | The disappearing quasi-biennial oscillation under sustained global warming. | PMC12957342 | True |
| review | -2 | Mapping tipping risks from Antarctic ice basins under global warming. | PMC12975511 | True |
| review | -2 | Moderate global warming does not rule out extreme global climate outcomes. | PMC13017523 | True |
| review | -2 | Modeling of fractional order DPG model insight global warming and pollution effe | PMC13061935 | True |
| review | -2 | Assessing 2‑Fluorobutane (CH3CHFCH2CH3) as a Climate-Friendly Alternative: Atmos | PMC13094374 | True |
| review | -2 | NIR Spectroscopy for Non-Destructive Prediction of Greenhouse Gas Emissions and  | PMC13165759 | True |
| review | -2 | Unexpected high subterranean biodiversity on rock glaciers threatened by global  | PMC13168501 | True |
| review | -2 | Contribution of hospitals and clinical services to global warming: a scoping sys | PMC13201132 | True |
| review | -2 | Lake sediment heatwaves under global warming. | PMC13259926 | True |
| review | -2 | Author Correction: Predicting biomass global warming potential with FT-NIR spect | PMC13279932 | True |
| review | -2 | Recovery time and exposure for six harmonized extreme climate event categories u |  | False |
| review | -3 | Effects of plastispheres and pristine microplastics on sediment microbial commun |  | False |
| review | -3 | Cyanobacteria bloom suppression by quagga mussels disappears with global warming |  | False |
| review | -3 | Imbalance Trajectories of GPP-TER Coupling Under Global Warming. |  | False |
| review | -3 | Global warming potential assessment of municipal solid waste management in Great |  | False |
| review | -3 | Global warming intensifies eutrophication and oxygen depletion in marine environ |  | False |
| review | -3 | Can rapid evolution allow insects to keep pace with global warming? Reviewing co |  | False |
| review | -3 | Ultra flash cold events under global warming. |  | False |
| review | -3 | Global warming intensifies compound renewable energy droughts |  | False |
| review | -3 | Changes in Snow Resources of Western Kazakhstan in the Context of Global Warming |  | False |
| review | -3 | Regional reorganization of long-range climate persistence under global warming |  | False |
| review | -3 | More Frequent and Severe Extreme Precipitation in Inner Mongolia Under Global Wa |  | False |
| review | -3 | Global Warming and Frequency Amplification of Extreme Sea Levels |  | False |
| review | -3 | Global warming acceleration in satellite observed lower-tropospheric temperature |  | False |
| review | -3 | Near-Term Inevitability, Long-Term Choice: First Exceedances of Global Warming T |  | False |
| review | -3 | Tipping Points and Emergent Phases of Species Diversity in Mutualistic Ecologica |  | False |
| review | -3 | Global Warming Drives Phenological Shifts and Hinders Reproductive Success in a  |  | False |
| review | -3 | Strengthened tropical Pacific influence on tropical Atlantic variability in glob |  | False |
| review | -3 | Genetic foundations of copper stress tolerance in safflower: bridging heavy meta |  | False |
| review | -3 | Heat but Not Cold Tolerance Is Phylogenetically Constrained in Greenlandic Terre |  | False |
| review | -5 | The earlier onset of Meiyu under global warming. |  | False |
